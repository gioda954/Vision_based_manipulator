
import numpy as np
import matplotlib.pyplot as plt
import pickle



filename = "lab_1_data_10s.pk1"



def load_from_pickle(filename: str):
    with open(filename, "rb") as f:
       return pickle.load(f)



def plot1(data1,data2):

    fig, axs = plt.subplots(4, 1, figsize=(8, 10), sharex=True)
    for i in range(4):
        axs[i].plot(data1, data2[:, i])
        axs[i].set_ylabel(f"Joint {i+1} [deg]")
        axs[i].grid(True)

    axs[-1].set_xlabel("Time [s]")
    plt.tight_layout()
    plt.show()


def plot2(time):

    delta = np.diff(time)
    plt.hist(delta, bins=20, edgecolor="black")
    plt.xlabel("delta time")
    plt.ylabel("frequency")
    plt.show()
    
  


def main():
    data = load_from_pickle(filename)

    t = np.array(data["timestamp_s"])
    Q = np.array(data["joint_degree"])

    #plot1(t,Q)

    plot2(t)

    


main()